from tkinter import *
from tkinter import messagebox
import pyttsx3

engine = pyttsx3.init()

win = Tk()

win.title("Text To Speech")
win.configure(bg="grey")
win.geometry("420x200")

def speak():
    t=entry1.get()
    engine.say(t)
    engine.runAndWait()
    engine.stop()
    if(t==""):
        messagebox.showerror("Error","Please Enter Text")
        
lf = LabelFrame(win, text="Text To Speech",font="40",bd=5,bg="grey")

lf.pack(fill="both", expand="yes",padx=10,pady=10)

Label(lf,text="text",font="30",padx=15,bd=5).pack(side=LEFT)

Text= StringVar()

entry1=Entry(lf,width=25,bd=5,font="20",textvariable=Text)
entry1.pack(side=LEFT,padx=10)

Button(lf,text="Convert",font=15,command=speak).pack(side=LEFT)

mainloop()